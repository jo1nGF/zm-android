#!/bin/sh
# ozma_update.sh boot|started|crashed|rollback APP_DIR - the install half of the in-app UPDATE (docs/update/WIFI_UPDATE.md).
#
# The app never replaces itself: it downloads, checks (signature, size, sha256) and unpacks into APP_DIR/.update/stage,
# writes .update/READY and exits with code 75. launch.sh then calls this script, which works only with renames on the
# SD card (each old file is copied aside, then the new one renamed over it: a running sh/binary keeps its old file,
# and every file is whole at every moment):
#   boot      before the app starts: finish/undo an interrupted install, a ROLLBACK request, or install READY.
#             Exit 10 = something was installed or rolled back: launch.sh re-runs itself (the new launch.sh).
#   started   right before the app runs: a new version on TRIAL counts its starts; the third start without the
#             app saying "healthy" (it removes TRIAL after 20 s of running, or on the player's QUIT: audit C-01)
#             puts the old version back (exit 10).
#   crashed   the app ended with an error while on TRIAL: exit 10 = start again (counts towards the rollback).
#   rollback  put the previous version back now (the UPDATE page writes .update/ROLLBACK and restarts instead).
# Files: .update/READY (staged version), stage/FILES (paths relative to APP_DIR), APPLYING (an install in progress),
# prev/JOURNAL + prev/files/ (what was replaced; "M path" = old copy in prev, "N path" = new file), prev/VERSION,
# TRIAL (start count of the new version), RESULT (one line for the UPDATE page), update.log.
# User data is never touched: the release zip carries no songs, samples of the user, renders or settings, and the
# journal only names files that are in the zip. The zip's data files (demo songs, OZMA KIT, the demos' prints) replace
# a file on the card only when it is one OZMA shipped (its sha256 is in the zip's SHIPPED.sha256, every version's):
# a file the player changed stays as it is and ours is not installed (mega QA C-09). Busybox 1.27 safe (no tac, no
# cp -n, no bash).
# Audits of 0.9.1: an undo / rollback that cannot put every file back says so, keeps prev/ and tries again on
# the next start (X-05); a download never installs over the same or a newer version unzipped by hand (C-04); a file
# list that names a file twice (X-06) or staged scripts that do not parse or have Windows line ends (C-22) install
# nothing; ROLLBACK keeps data files the player changed after the install (X-18) and a copy of the lesson song
# MYTRACK (C-02); without sha256sum a data file on the card is kept, never replaced blind (C-21). prev/TO names the
# version the download installed: a different version on the card (unzipped by hand) makes prev/ stale and it goes
# (C-04, second half), so a ROLLBACK never puts an older version over a hand install.
set -u
CMD=${1:-}
A=${2:-$(CDPATH= cd -- "$(dirname -- "$0")" && pwd)}
case "$A" in ?*/) A=${A%/} ;; esac
# No command = started from a menu, not by launch.sh. Knulli / Batocera EmulationStation and other Ports lists show every
# .sh as a game, so an app folder copied inside roms/ports lists this file as "ozma_update" (tester report 2026-11-24,
# Brick Pro, Knulli a133 preview: black screen, back to Ports). That entry now opens OZMA like "launch" does; nothing is
# installed or written here (the update itself only ever runs from launch.sh, with a command).
if [ -z "$CMD" ]; then
    [ -f "$A/launch.sh" ] && exec sh "$A/launch.sh"
    exit 0
fi
U=$A/.update
P=$U/prev
LOG=$U/update.log
mkdir -p "$U" 2>/dev/null || exit 0
log() { echo "$(date '+%Y-%m-%d %H:%M:%S') $*" >> "$LOG"; }
result() { echo "$*" > "$U/RESULT.tmp" && mv -f "$U/RESULT.tmp" "$U/RESULT"; echo "$*" > "$U/NOTICE"; log "$*"; } # NOTICE: one toast on the next start
oneline() { [ -f "$1" ] && sed -n '1{s/[^A-Za-z0-9._-]//g;p;}' "$1"; }
curver() { oneline "$A/.update/CURRENT"; }
# the version on the card: VERSION.txt ("OZMA 0.9.1 (sha)", in every zip) also sees a zip unzipped by hand (C-04);
# the version the app last wrote when there is none
zipver() { [ -f "$1" ] && sed -n '1{s/^OZMA //;s/ .*//;s/[^A-Za-z0-9._-]//g;p;}' "$1"; } # "OZMA 0.9.1 (sha)" -> 0.9.1
installed() {
    h=$(zipver "$A/VERSION.txt")
    if [ -n "$h" ]; then echo "$h"; else curver; fi
}
# 1 when version $1 is newer than $2, 0 the same, -1 older; the rules of compareVersions in src/platform/update.cpp:
# numbers split on '.', missing ones are 0, "-tag.N" is a pre-release before its release, tags as text, then N
vercmp() {
    awk -v a="$1" -v b="$2" 'function pv(s, V,   k, base, pre, x, n, i, j) {
        k = index(s, "-"); if (k) { base = substr(s, 1, k - 1); pre = substr(s, k + 1) } else { base = s; pre = "" }
        n = split(base, x, "."); for (i = 1; i <= 4; i++) V[i] = (i <= n) ? x[i] + 0 : 0
        V[5] = k > 0; j = index(pre, ".")
        if (j) { V[6] = tolower(substr(pre, 1, j - 1)); V[7] = substr(pre, j + 1) + 0 } else { V[6] = tolower(pre); V[7] = 0 } }
      BEGIN { pv(a, X); pv(b, Y); r = 0
        for (i = 1; i <= 4 && !r; i++) if (X[i] != Y[i]) r = X[i] < Y[i] ? -1 : 1
        if (!r && X[5] != Y[5]) r = X[5] ? -1 : 1
        if (!r && X[5]) { if (X[6] != Y[6]) r = X[6] < Y[6] ? -1 : 1; else if (X[7] != Y[7]) r = X[7] < Y[7] ? -1 : 1 }
        print r }'
}
# "@menu/x" = the stock OS menu entry <card>/Apps/OZMA/x (only when OZMA runs from <card>/App/OZMA and the card has
# an Apps folder); everything else is relative to APP_DIR
MENU=""
case "$A" in */App/OZMA) [ -d "${A%/App/OZMA}/Apps" ] && MENU="${A%/App/OZMA}/Apps/OZMA" ;; esac
dest() {
    case "$1" in
    @menu/*) [ -n "$MENU" ] && echo "$MENU/${1#@menu/}" ;;
    *) echo "$A/$1" ;;
    esac
}

# Check a data/* file ($1 on disk, $2 relative path) against an older version's SHIPPED.sha256 snapshot ($3).
# Returns 0 when $3 is absent, sha256sum is unavailable, $2 is not listed in $3, or an exact "<hash>  <path>" entry matches.
# Returns 1 when $2 is listed in $3 and no entry for $2 matches $1's sha256.
shipped_file_ok() {
    [ -n "${3:-}" ] && [ -f "$3" ] && command -v sha256sum >/dev/null 2>&1 || return 0
    bh=$(sha256sum "$1" | cut -d' ' -f1)
    [ -n "$bh" ] || return 1
    awk -v f="$2" -v h="$bh" '
        /^#/ || NF < 2 { next }
        { p = $0; sub(/^[0-9a-fA-F]+[ ]+/, "", p)
          if (p == f) { listed = 1; if (tolower($1) == tolower(h)) ok = 1 } }
        END { exit (listed && !ok) ? 1 : 0 }
    ' "$3"
}

# undo prev/JOURNAL, newest line first; safe to run on a half-done install (each line checks what really happened)
# and again after a failed run (what was put back is no longer in prev/files). $1 = SHIPPED.now (player-change check, X-18),
# $2 = SHIPPED.prev (old version's own SHIPPED.sha256 snapshot, when the old version had one). Returns 1 when a file could
# not be put back or removed (X-05): the caller keeps prev/ and the journal and says so.
undo() {
    [ -f "$P/JOURNAL" ] || return 1
    sed -n '1!G;h;$p' "$P/JOURNAL" > "$U/JOURNAL.rev" || return 1
    ufail=0
    while IFS= read -r line; do
        k=${line%% *}; f=${line#* }
        case "$f" in
        ""|/*|*..*) continue ;;
        @menu/*)
            if [ -z "$MENU" ]; then
                rm -f "$P/files/$f" 2>/dev/null
                log "undo: no stock menu folder for $f, skipped"
                continue
            fi ;;
        esac
        d=$(dest "$f")
        [ -n "$d" ] || continue
        case "$k" in
        M) [ -e "$P/files/$f" ] || continue
           if [ -n "${1:-}" ] && changed "$f" "$1"; then log "rollback: kept the player's $f"; continue; fi
           case "$f" in
           data/*)
               if [ -n "${2:-}" ] && ! shipped_file_ok "$P/files/$f" "$f" "$2"; then
                   log "undo: backup $f failed SHIPPED.sha256 check"; ufail=1; continue
               fi ;;
           esac
           { mkdir -p "$(dirname "$d")" && mv -f "$P/files/$f" "$d"; } || { log "undo: could not put back $f"; ufail=1; } ;;
        N) [ -e "$d" ] && [ ! -e "$U/stage/App/$f" ] || continue
           if [ -n "${1:-}" ] && changed "$f" "$1"; then log "rollback: kept the player's $f"; continue; fi
           rm -f "$d" || { log "undo: could not remove $f"; ufail=1; } ;;
        esac
    done < "$U/JOURNAL.rev"
    rm -f "$U/JOURNAL.rev"
    sync
    return $ufail
}

# true when $1 (relative to APP_DIR) is a data file on the card that is not one OZMA ever shipped by the list $2
# (a SHIPPED.sha256): the player changed it. No list (older zips): false (replaced as before). No sha256sum on this
# system: true, the file on the card stays (C-21: never replace blind; it is logged).
changed() {
    case "$1" in data/*) ;; *) return 1 ;; esac
    [ -f "$2" ] || return 1
    d=$(dest "$1"); [ -f "$d" ] || return 1
    command -v sha256sum >/dev/null 2>&1 || { log "no sha256sum: $1 left as it is"; return 0; }
    h=$(sha256sum "$d" | cut -d' ' -f1)
    [ -n "$h" ] || return 1
    grep -q "^$h " "$2" && return 1
    return 0
}
mine() { changed "$1" "$S/SHIPPED.sha256"; }

# The install screen: bin/ozma_say -r draws the UPDATE page's rocket and "UPDATING OZMA, DO NOT TURN OFF" while the files
# move, so a start that installs does not look hung. Only a picture, never a step of the install: it runs from a copy in
# /tmp (RAM), so the install never renames over a running program and writes nothing more to the card; it gets only the
# version names, and say_stop kills it (KILL: it cannot be ignored or delayed) and reaps it before boot exits. No
# ozma_say, no /tmp, a copy or start that fails, no screen: no picture, and the install goes on exactly as before.
SAYPID=""; SAYBIN=""
say_start() { # OLD NEW
    [ -x "$A/bin/ozma_say" ] || return 0
    SAYBIN=${TMPDIR:-/tmp}/ozma-update-say.$$
    { cp "$A/bin/ozma_say" "$SAYBIN" && chmod 0755 "$SAYBIN"; } 2>/dev/null || { rm -f "$SAYBIN" 2>/dev/null; SAYBIN=""; return 0; }
    "$SAYBIN" -r -p $$ "UPDATING OZMA" "DO NOT TURN OFF" "${1:-?} > $2" </dev/null >/dev/null 2>&1 &
    SAYPID=$!
    return 0
}
say_stop() {
    if [ -n "$SAYPID" ]; then kill -9 "$SAYPID" 2>/dev/null; wait "$SAYPID" 2>/dev/null; fi
    [ -n "$SAYBIN" ] && rm -f "$SAYBIN" 2>/dev/null
    SAYPID=""; SAYBIN=""
    return 0
}

drop() { rm -f "$U/READY"; rm -rf "${U:?}/stage"; result "$1"; } # the stage goes, nothing was moved
# an install step failed: put the old files back; when even that fails, APPLYING, prev/ and the stage stay and the
# next start finishes the undo (X-05)
failed() {
    log "$2"
    if undo; then rm -f "$U/APPLYING" "$U/READY"; rm -rf "${U:?}/stage"; result "FAILED $v: $1, OLD VERSION KEPT"
    else result "FAILED $v: $1, OLD VERSION BACK ON NEXT START"; fi
}

apply() {
    v=$(oneline "$U/READY")
    S=$U/stage/App
    if [ -z "$v" ] || [ ! -f "$U/stage/FILES" ] || [ ! -f "$S/bricktracker" ] || [ ! -f "$S/launch.sh" ]; then
        drop "FAILED: THE DOWNLOAD WAS INCOMPLETE"; return 1
    fi
    # C-04: never over the same or a newer version (a zip unzipped by hand while this download waited)
    old=$(installed)
    if [ -n "$old" ] && [ "$(vercmp "$v" "$old")" -le 0 ]; then log "skipped $v: the card has $old"; drop "ALREADY ON $old"; return 1; fi # the download ($v) was not newer; short: fits LAST: on UPDATE
    # every staged file must be there before anything moves
    while IFS= read -r f; do
        case "$f" in ""|/*|*..*|.update/*) drop "FAILED $v: BAD FILE LIST"; return 1 ;; esac
        [ -f "$S/$f" ] || { drop "FAILED $v: FILE MISSING ($f)"; return 1; }
    done < "$U/stage/FILES"
    # X-06: a name twice (also only in upper / lower case: one file on FAT / exFAT) would back up the new file
    [ -z "$(tr 'A-Z' 'a-z' < "$U/stage/FILES" | sort | uniq -d | sed -n 1p)" ] || { drop "FAILED $v: BAD FILE LIST (A FILE TWICE)"; return 1; }
    # C-22: the scripts the menu runs must parse, with Unix line ends, before they replace working ones: every staged
    # .sh (launch.sh, ozma_update.sh, the menu entry, and platform/detect.sh that launch.sh sources since multi-OS)
    while IFS= read -r f; do
        case "$f" in *.sh) ;; *) continue ;; esac
        if grep -q "$(printf '\r')" "$S/$f" || ! sh -n "$S/$f" 2>/dev/null; then drop "FAILED $v: BAD LAUNCHER ($f)"; return 1; fi
    done < "$U/stage/FILES"
    say_start "$old" "$v"   # every check passed: from here on the files move (stopped in boot, whatever apply returns)
    rm -rf "$P"; mkdir -p "$P/files"
    echo "${old:-unknown}" > "$P/VERSION"
    # C-04: whose backup this is (stale() below), as the zip's own VERSION.txt spells it: the manifest's name may differ
    # (1.1.0 vs 1.1.0-rc.1). A zip without VERSION.txt writes no TO: no hand-install guess for it.
    to=$(zipver "$S/VERSION.txt"); [ -n "$to" ] && echo "$to" > "$P/TO"
    # the whole journal first, then the moves: a power cut at any point is undone on the next boot
    : > "$P/JOURNAL"
    while IFS= read -r f; do
        case "$f" in @menu/*) [ -n "$MENU" ] || continue ;; esac   # no stock menu on this card: leave it out
        if mine "$f"; then log "kept the player's $f"; continue; fi # C-09: the player's own version stays
        if [ -e "$(dest "$f")" ]; then echo "M $f" >> "$P/JOURNAL"; else echo "N $f" >> "$P/JOURNAL"; fi
    done < "$U/stage/FILES"
    echo "$v" > "$U/APPLYING"
    sync
    log "install $v over ${old:-unknown}: $(wc -l < "$U/stage/FILES") files"
    while IFS= read -r line; do
        k=${line%% *}; f=${line#* }; d=$(dest "$f")
        mkdir -p "$(dirname "$d")"
        # the old file is COPIED aside, then the new one renamed over it: every file is always whole, old or new,
        # so a power cut never leaves the menu without launch.sh (FAT/exFAT has no hard links to do it cheaper)
        if [ "$k" = M ]; then
            mkdir -p "$(dirname "$P/files/$f")"
            { cp -p "$d" "$P/files/$f.part" && mv -f "$P/files/$f.part" "$P/files/$f"; } || { failed "SD CARD FULL OR WRITE ERROR" "keep old $f failed"; return 1; }
        fi
        mv -f "$S/$f" "$d" || { failed "SD CARD WRITE ERROR" "move new $f failed"; return 1; }
    done < "$P/JOURNAL"
    chmod 0755 "$A/bricktracker" "$A/launch.sh" "$A/ozma_update.sh" 2>/dev/null
    [ -n "$MENU" ] && chmod 0755 "$MENU/launch.sh" 2>/dev/null
    [ -d "$A/bin" ] && chmod 0755 "$A/bin/"* 2>/dev/null
    echo "$v" > "$U/CURRENT"
    echo 0 > "$U/TRIAL"
    rm -rf "$U/stage"; rm -f "$U/READY" "$U/APPLYING" "$U/UNFINISHED_BOOTS" "$U/RESTART_GUARD"
    sync
    result "INSTALLED $v"
    return 0
}

# The open song as the new version left it, kept as a visible song before the old version starts: an older version
# reads only the parts it knows and autosaves the song back without the newer settings (mega QA L9-01: 0.8.2 drops
# the DUCK, FINISHER and FX SECTOR blocks). Back on the newer version the player loads AUTOSAVE_<version> to get
# them back. The lesson song MYTRACK too (C-02): an older version that cannot read it starts a fresh one over it.
# Only a copy is made; nothing of the user's is moved or deleted.
keepcopy() { # FILE BASE NAME_MARKER: Songs/FILE -> Songs/<chosen>.ozm; returns 1 when copy fails
    [ -s "$D/$1" ] || return 0
    n=""
    [ -f "$3" ] && n=$(sed -n '1{s/[\r\n]//g;p;}' "$3")
    if [ -z "$n" ]; then
        n=$2
        # a second rollback of the same version keeps the first copy too (mega QA R2A-05): _2, _3, ...
        if [ -e "$D/$n.ozm" ]; then i=2; while [ -e "$D/${n}_$i.ozm" ] && [ $i -lt 99 ]; do i=$((i + 1)); done; n=${n}_$i; fi
        if [ -d "$P" ]; then
            { echo "$n" > "$3.tmp" && mv -f "$3.tmp" "$3"; } 2>/dev/null || echo "$n" > "$3" 2>/dev/null
        fi
    fi
    if [ -f "$D/$n.ozm" ] && cmp -s "$D/$1" "$D/$n.ozm"; then return 0; fi
    rm -f "$D/$n.ozm.part" 2>/dev/null
    if cp -p "$D/$1" "$D/$n.ozm.part" && mv -f "$D/$n.ozm.part" "$D/$n.ozm"; then
        log "rollback: Songs/$1 kept as Songs/$n.ozm"
        return 0
    fi
    rm -f "${D:?}/${n:?}.ozm.part" 2>/dev/null
    log "rollback: could not keep Songs/$1"
    return 1
}
keepsong() { # $1 = the version that is rolled back; returns 1 when a song copy fails (retried before rollback finishes)
    D=${BT_DATA:-$A/data}/Songs
    vv=$(echo "${1:-NEW}" | tr '.' '_')
    kfail=0
    if [ ! -f "$P/SONGS_AUTOSAVE" ]; then
        if keepcopy .autosave.ozm "AUTOSAVE_$vv" "$P/SONGS_AUTOSAVE_NAME"; then
            [ -d "$P" ] && : > "$P/SONGS_AUTOSAVE" 2>/dev/null
        else kfail=1; fi
    fi
    if [ ! -f "$P/SONGS_MYTRACK" ]; then
        msrc=MYTRACK.ozm; [ -s "$D/$msrc" ] || msrc=MYTRACK.ozm.bak
        if keepcopy "$msrc" "MYTRACK_$vv" "$P/SONGS_MYTRACK_NAME"; then
            [ -d "$P" ] && : > "$P/SONGS_MYTRACK" 2>/dev/null
        else kfail=1; fi
    fi
    return $kfail
}

# OZ92-A05: rolling back discards any waiting download or partial zip so the launcher never installs it over the rollback
purge_staged() {
    rm -f "$U/READY" "$U/latest.json.new" "$U/latest.json.sig.new"
    rm -rf "${U:?}/stage" "${U:?}/dl"
}

# C-04 (second half): prev/ is the backup the download's install made (prev/TO = that version). A different version
# unzipped by hand since then makes it stale: a ROLLBACK from it would put the version before the download over the
# hand install and leave the files only the hand install has. prev/ holds only OZMA's own files (the journal names
# files of the zip, a data file only when it was the shipped one, C-09), never the player's, so it goes. The trial
# and a waiting ROLLBACK were for the downloaded version: they go too. No prev/TO (made by an older installer): kept.
# Never during an unfinished install (APPLYING) or an unfinished rollback (ROLLBACK_IN_PROGRESS / prev/FROM).
stale() { # 0 = prev/ was stale and is gone
    [ -f "$P/TO" ] && [ ! -f "$U/APPLYING" ] && [ ! -f "$U/ROLLBACK_IN_PROGRESS" ] && [ ! -f "$P/FROM" ] || return 1
    to=$(oneline "$P/TO"); h=$(zipver "$A/VERSION.txt")   # VERSION.txt on both sides, never the app's CURRENT
    [ -n "$to" ] && [ -n "$h" ] && [ "$(vercmp "$h" "$to")" != 0 ] || return 1
    log "the card has $h (unzipped by hand), the backup is from the install of $to: no rollback to $(oneline "$P/VERSION")"
    rm -rf "${P:?}"; rm -f "$U/TRIAL" "$U/UNFINISHED_BOOTS" "$U/RESTART_GUARD"
    if [ -f "$U/ROLLBACK" ]; then rm -f "$U/ROLLBACK"; result "NO OLDER VERSION KEPT"; fi
    return 0
}

# OZ92-M11p1: verify every restored file and the old version's SHIPPED.sha256 snapshot before clearing prev/ and markers
verify_rollback() { # $1 = prev/SHIPPED.now, $2 = prev/SHIPPED.prev (when the old version had SHIPPED.sha256)
    [ -f "$P/JOURNAL" ] || return 1
    vfail=0
    while IFS= read -r line; do
        k=${line%% *}; f=${line#* }
        case "$f" in
        ""|/*|*..*) continue ;;
        @menu/*) [ -n "$MENU" ] || continue ;;
        esac
        d=$(dest "$f")
        [ -n "$d" ] || continue
        case "$k" in
        M)
            if [ -e "$P/files/$f" ]; then
                if [ -n "${1:-}" ] && changed "$f" "$1"; then
                    [ -f "$d" ] || { log "rollback verify: kept player file missing ($f)"; vfail=1; }
                    continue
                fi
                log "rollback verify: backup still pending ($f)"; vfail=1; continue
            fi
            [ -f "$d" ] || { log "rollback verify: restored file missing ($f)"; vfail=1; continue; }
            case "$f" in
            data/*)
                if [ -n "${2:-}" ] && ! shipped_file_ok "$d" "$f" "$2"; then
                    log "rollback verify: $f does not match restored SHIPPED.sha256"; vfail=1
                fi ;;
            esac ;;
        N)
            if [ -e "$d" ]; then
                if [ -n "${1:-}" ] && changed "$f" "$1"; then continue; fi
                log "rollback verify: new file still present ($f)"; vfail=1
            fi ;;
        esac
    done < "$P/JOURNAL"
    [ -f "$A/bricktracker" ] || { log "rollback verify: bricktracker missing"; vfail=1; }
    for s in "$A/launch.sh" "$A/ozma_update.sh"; do
        if [ -f "$s" ] && ! sh -n "$s" 2>/dev/null; then
            log "rollback verify: $s failed syntax check"; vfail=1
        fi
    done
    return $vfail
}

rollback() { # $1 = why. 0 = done, 1 = no previous version, 2 = not finished: prev/ kept, tried again on the next start
    stale
    if ! [ -f "$P/JOURNAL" ]; then
        if [ -f "$U/ROLLBACK_IN_PROGRESS" ]; then
            rm -rf "${P:?}"
            rm -f "$U/TRIAL" "$U/UNFINISHED_BOOTS" "$U/RESTART_GUARD" "$U/ROLLBACK" "$U/ROLLBACK_IN_PROGRESS" "${TMPDIR:-/tmp}/ozma-crashed.$PPID" 2>/dev/null
            sync
            return 0
        fi
        rm -f "$U/ROLLBACK" 2>/dev/null
        log "rollback: no previous version kept"
        return 1
    fi
    why=${1:-ROLLED BACK}
    if [ -f "$U/ROLLBACK_IN_PROGRESS" ]; then
        saved_why=$(sed -n '1{s/[\r\n]//g;p;}' "$U/ROLLBACK_IN_PROGRESS")
        [ -n "$saved_why" ] && why=$saved_why
    else
        { echo "$why" > "$U/ROLLBACK_IN_PROGRESS.tmp" && mv -f "$U/ROLLBACK_IN_PROGRESS.tmp" "$U/ROLLBACK_IN_PROGRESS"; } 2>/dev/null \
            || echo "$why" > "$U/ROLLBACK_IN_PROGRESS" 2>/dev/null
    fi
    [ -f "$U/ROLLBACK" ] || echo 1 > "$U/ROLLBACK" 2>/dev/null
    purge_staged
    # a retry (X-05 / OZ92-M11p1) keeps what the first try saw: the version left, both shipped lists, the songs already copied
    if [ ! -f "$P/FROM" ]; then
        fb=$(curver); [ -n "$fb" ] || fb=$(installed)
        echo "${fb:-unknown}" > "$P/FROM.tmp" && mv -f "$P/FROM.tmp" "$P/FROM"
    fi
    if [ ! -f "$P/SHIPPED.now" ] && [ -f "$A/SHIPPED.sha256" ]; then
        cp -p "$A/SHIPPED.sha256" "$P/SHIPPED.now.tmp" 2>/dev/null && mv -f "$P/SHIPPED.now.tmp" "$P/SHIPPED.now" 2>/dev/null
    fi
    if [ ! -f "$P/SHIPPED.prev" ] && [ -f "$P/files/SHIPPED.sha256" ]; then
        cp -p "$P/files/SHIPPED.sha256" "$P/SHIPPED.prev.tmp" 2>/dev/null && mv -f "$P/SHIPPED.prev.tmp" "$P/SHIPPED.prev" 2>/dev/null
    fi
    sync
    bad=$(oneline "$P/FROM"); prev=$(oneline "$P/VERSION")
    [ -f "$P/SONGS_KEPT" ] || { keepsong "$bad" && : > "$P/SONGS_KEPT" 2>/dev/null; sync; }
    if ! undo "$P/SHIPPED.now" "$P/SHIPPED.prev" || ! verify_rollback "$P/SHIPPED.now" "$P/SHIPPED.prev"; then
        echo 1 > "$U/ROLLBACK" 2>/dev/null
        result "ROLLBACK NOT DONE YET"   # the log says which file; the next start tries again
        return 2
    fi
    # If keepsong hit ENOSPC before undo freed the newer release's files, retry song rescue once now
    [ -f "$P/SONGS_KEPT" ] || { keepsong "$bad" && : > "$P/SONGS_KEPT" 2>/dev/null; sync; }
    chmod 0755 "$A/bricktracker" "$A/launch.sh" "$A/ozma_update.sh" 2>/dev/null
    [ -n "$MENU" ] && [ -f "$MENU/launch.sh" ] && chmod 0755 "$MENU/launch.sh" 2>/dev/null
    [ -d "$A/bin" ] && chmod 0755 "$A/bin/"* 2>/dev/null
    echo "${prev:-unknown}" > "$U/CURRENT.tmp" && mv -f "$U/CURRENT.tmp" "$U/CURRENT"
    result "$why ${bad:-?} -> BACK ON ${prev:-THE OLD VERSION}"
    rm -rf "$P"
    rm -f "$U/TRIAL" "$U/UNFINISHED_BOOTS" "$U/RESTART_GUARD" "$U/ROLLBACK" "$U/ROLLBACK_IN_PROGRESS" "${TMPDIR:-/tmp}/ozma-crashed.$PPID" 2>/dev/null
    sync
    return 0
}

case "$CMD" in
boot)
    if [ -f "$U/APPLYING" ]; then
        v=$(oneline "$U/APPLYING"); log "an install of $v was interrupted: undo"
        # X-05: a file that cannot be put back keeps the journal and the old copies for the next start
        if ! undo; then result "FAILED ${v:-?}: SD CARD ERROR, OLD VERSION BACK ON NEXT START"; exit 0; fi
        rm -rf "$P" "$U/stage"; rm -f "$U/APPLYING" "$U/READY" "$U/TRIAL" "$U/UNFINISHED_BOOTS" "$U/RESTART_GUARD" "${TMPDIR:-/tmp}/ozma-crashed.$PPID" 2>/dev/null
        result "FAILED ${v:-?}: INTERRUPTED, OLD VERSION KEPT"; exit 10
    fi
    stale   # C-04: a hand install since the last download: no rollback over it
    if [ -f "$U/ROLLBACK_IN_PROGRESS" ] || [ -f "$U/ROLLBACK" ]; then
        rollback "ROLLED BACK"; r=$?
        [ $r = 0 ] && exit 10
        exit 0   # not finished or nothing kept: never an install over a rollback start
    fi
    if [ -f "$U/TRIAL" ]; then
        tn=$(sed -n '1{s/[^0-9]//g;p;}' "$U/TRIAL")
        [ "${tn:-0}" -ge 2 ] && exit 0   # OZ92-A05: trial failed twice; let started roll back to prev/ instead of installing READY over it
    fi
    if [ -f "$U/READY" ]; then
        apply; r=$?; say_stop
        if [ $r = 0 ]; then rm -f "${TMPDIR:-/tmp}/ozma-crashed.$PPID" 2>/dev/null; exit 10; fi
    fi
    exit 0 ;;
started)
    [ -f "$U/TRIAL" ] || exit 0
    [ -f "$U/ROLLBACK_IN_PROGRESS" ] && exit 0
    n=$(sed -n '1{s/[^0-9]//g;p;}' "$U/TRIAL"); n=$(( ${n:-0} + 1 ))
    if [ "$n" -gt 2 ]; then
        rollback "DID NOT START:"; r=$?
        [ $r = 0 ] && exit 10
        [ $r = 1 ] && rm -f "$U/TRIAL" "$U/UNFINISHED_BOOTS" "$U/RESTART_GUARD" 2>/dev/null
        [ $r = 2 ] && echo 3 > "$U/TRIAL" 2>/dev/null
        exit 0
    fi
    echo "$n" > "$U/TRIAL" 2>/dev/null; log "trial start $n of $(curver)"
    exit 0 ;;
crashed)
    if [ -f "$U/TRIAL" ]; then
        tn=$(sed -n '1{s/[^0-9]//g;p;}' "$U/TRIAL")
        cf=${TMPDIR:-/tmp}/ozma-crashed.$PPID
        cn=$(sed -n '1{s/[^0-9]//g;p;}' "$cf" 2>/dev/null); cn=$(( ${cn:-0} + 1 ))
        log "$(curver) ended with an error on trial"
        cp -f "$A/log.txt" "$U/trial-crash.log" 2>/dev/null
        if [ -f "$U/ROLLBACK_IN_PROGRESS" ] || [ -f "$U/ROLLBACK" ] || [ "${tn:-0}" -gt 2 ] || [ "$cn" -gt 2 ]; then
            rm -f "$cf" 2>/dev/null
            log "trial restart limit reached or rollback pending: stopping restart loop"
            exit 0
        fi
        echo "$cn" > "$cf" 2>/dev/null
        exit 10
    fi
    exit 0 ;;
rollback)
    rollback "ROLLED BACK" && exit 10; exit 1 ;;
*)
    sed -n 2,16p "$0"; exit 2 ;;
esac
