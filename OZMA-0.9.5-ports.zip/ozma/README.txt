OZMA as a port (PortMaster format) - NOT TESTED ON A REAL DEVICE YET
====================================================================

For 64-bit ARM handhelds with a Ports list: ROCKNIX, AmberELEC, ArkOS, dArkOS, muOS (its Applications entry, the
-muos.muxapp, is the better way there) and others. OZMA is made for the TrimUI Brick; on every other device it is
not tested on a real device yet. Please tell us how it works (see REPORTING A BUG).
For the TrimUI Brick, download OZMA-0.9.5.zip instead (not this one).

INSTALL
-------
Unzip OZMA-0.9.5-ports.zip into the ports folder of your card, merging folders, so it holds:
    OZMA.sh        what you start from the Ports list
    ozma/          the app
    ozma-data/     your songs, samples and settings, with the demos and OZMA KIT
Ports folder: ROCKNIX and AmberELEC roms/ports, ArkOS and dArkOS roms/ports (or roms2/ports), muOS ROMS/Ports.
Refresh the game list, then start OZMA from Ports.

Your songs stay in ports/ozma-data, beside the app: deleting or reinstalling OZMA (also with PortMaster) leaves that
folder alone. To update, unzip the new version the same way: your songs stay. Back up ports/ozma-data now and then.
Your own WAV files go in the folder OZMA/Samples beside the ports folder (on muOS: at the top of the card). OZMA
makes the folder when it starts, shows the files in its sample list and only reads them.
When PortMaster is installed, OZMA uses its button mapping for your device; without it OZMA asks you to press each
button once.

YOUR SONGS
----------
Your songs, samples and settings live in ports/ozma-data, shared by the systems on the card.
To update: PROJECT > UPDATE over Wi-Fi downloads and installs a new version only on the Brick with the stock TrimUI
OS or spruce. On every other system it only tells you that a new version is out (on MinUI it is off): install the
new package by hand, the same way as the first time. The zip brings only the demo songs, OZMA KIT and the demos'
own prints into data, so your songs stay. A demo you change and SAVE goes to data/Songs as your own song; the
demos themselves stay as they are.

This is a beta: back up the whole ports/ozma-data folder now and then (songs point to samples and recordings in it).

YOUR OWN SOUNDS
---------------
Put your own WAV files in the folder OZMA/Samples at the top of the SD card. OZMA makes this folder when it starts;
folders inside it are fine. The sample list shows them together with OZMA's own sounds. OZMA only reads this folder:
it never changes, moves or deletes a file in it. Sounds you already keep in ports/ozma-data/Samples stay there and keep
working. Back up OZMA/Samples together with ports/ozma-data.

DEMOS AND OZMA KIT
------------------
Three demo songs are at the end of the LESSONS list in HELP: press MENU (if it opens on KEYS, press LEFT for
LESSONS), then UP on the first lesson jumps to them; A opens one. They are made only with OZMA's own instruments:
DEEP FIELD (deep house), REDSHIFT (techno) and ION DRIVE (drum and bass). Open them, take them apart, learn from them.
OZMA KIT (data/Samples/OZMA KIT) is a set of drum and FX sounds made for OZMA. You may use them in your own
music, also commercially (see LICENSE.txt).

STUDIO MODE AND RECOVERY
------------------------
While OZMA runs it puts the Brick in "studio mode": all CPU cores on, background services (sync, file sharing,
media server) paused. Everything is restored when you quit.
If OZMA was force-closed or crashed: open OZMA and quit it once more to bring those services back, or restart
the Brick.

USB: TWO PORTS, TWO JOBS
------------------------
TOP USB port = OZMA is the host. Plug in a MIDI keyboard or controller (for example an Arturia MiniLab), or a
class-compliant sound card or groovebox (for example an Elektron Tonverk). A device with a sound card gets the
Brick's audio and MIDI over one cable. Nothing to switch on: OZMA finds it when it is plugged in.
  PROJECT > AUDIO > OUTPUT   AUTO: a USB sound card on the top port takes over the sound while it is plugged in.
                             SPEAKER: the sound always stays on the Brick.
  PROJECT > MIDI > CLOCK OUT ON: OZMA sends tempo + start/stop, so the other device follows OZMA.
  PROJECT > MIDI > CLOCK IN AUTO: OZMA follows a clock it receives (press play on the master).

BOTTOM USB-C port = OZMA is the device. Plug it into a computer, phone or tablet: the Brick becomes a sound card +
MIDI port that needs no driver. It charges over the same cable.
  PROJECT > AUDIO > USB AUDIO   OUT: the Brick plays into the computer.  IN: the computer plays into the Brick.
                                OFF: the port works as usual. Takes effect the next time you start OZMA.
  PROJECT > AUDIO > BUFFER      bigger = no dropouts on a busy Brick, a little more delay.
  PROJECT > AUDIO > BRICK       while the computer records: the Brick plays too, or stays silent.

More detail and step-by-step setups: CHANGELOG.txt.

REPORTING A BUG
---------------
Join the OZMA Discord (https://discord.gg/uX7gvn2Ary) and make a post in #bugs, one bug per post. Please give the OZMA version
(ports/ozma/VERSION.txt), your handheld and its system, what happened and how to make it happen again, and attach
ports/ozma/log.txt and ports/ozma/studio.log. To get these files: quit OZMA, turn the Brick off and put the SD card
in a computer or a phone (card reader). A phone video helps a lot for sound and screen problems.
On NextUI, Knulli and other handhelds OZMA also writes a tester report into ports/ozma when it starts and after every
run (so it is there even if you had to switch the console off): a file whose name starts with OZMA_REPORT_ (your
device and system follow). Attach it too, and please do not delete the OZMA folder before you have copied it. It is made on your device only and is
never sent anywhere; it holds what OZMA found on the system, the end of the last run's log, checksums of OZMA's
own files and a random install number (made once on your card, not from your device). No passwords, no Wi-Fi
settings, no serial numbers. Open it to see everything it holds.

Official page: https://orumet.itch.io/ozma
LICENSE.txt: what you may do with OZMA. THIRD_PARTY_NOTICES.txt: the open-source parts and fonts inside.
