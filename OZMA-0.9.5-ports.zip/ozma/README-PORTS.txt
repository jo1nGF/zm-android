OZMA as a port (PortMaster format) - NOT TESTED ON A REAL DEVICE YET
====================================================================

For 64-bit ARM handhelds with a Ports list: ROCKNIX, AmberELEC, ArkOS, dArkOS, muOS (its Applications entry, the
-muos.muxapp, is the better way there) and others. OZMA is made for the TrimUI Brick; on every other device it is
not tested on a real device yet. Please tell us how it works (see REPORTING A BUG).
For the TrimUI Brick, download OZMA-0.9.5.zip instead (not this one).

INSTALL
-------
Unzip OZMA-0.9.5-ports.zip into the ports folder of your card, merging folders, so it holds:
    OZMA.sh        what you start from the Ports list
    ozma/          the app
    ozma-data/     your songs, samples and settings, with the demos and OZMA KIT
Ports folder: ROCKNIX and AmberELEC roms/ports, ArkOS and dArkOS roms/ports (or roms2/ports), muOS ROMS/Ports.
Refresh the game list, then start OZMA from Ports.

Your songs stay in ports/ozma-data, beside the app: deleting or reinstalling OZMA (also with PortMaster) leaves that
folder alone. To update, unzip the new version the same way: your songs stay. Back up ports/ozma-data now and then.
Your own WAV files go in the folder OZMA/Samples beside the ports folder (on muOS: at the top of the card). OZMA
makes the folder when it starts, shows the files in its sample list and only reads them.
When PortMaster is installed, OZMA uses its button mapping for your device; without it OZMA asks you to press each
button once.
