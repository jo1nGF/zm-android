#!/bin/bash
# EXPERIMENTAL - untested on every device it is meant for. OZMA is made for the TrimUI Brick.
# A "Ports" entry for other handheld systems with PortMaster-style ports: copy THIS file into the ports folder,
#   muOS <card>/ROMS/Ports/OZMA.sh | ROCKNIX, AmberELEC /storage/roms/ports | ArkOS, dArkOS /roms/ports or /roms2/ports
# and keep the OZMA zip unpacked at the card root (App/OZMA). Never for the Brick (Apps/OZMA, App/OZMA, Knulli's
# OZMA.sh there). It only hands over to App/OZMA/launch.sh. bash, because PortMaster's control.txt is bash.
# App/OZMA is looked for in: $OZMA_APP, <here>/ozma (the PortMaster-format zip, scripts/ports/package.sh: the app
# beside this file, its songs in <here>/ozma-data, D9), <here>/../App/OZMA, <here>/../../App/OZMA, <here>/OZMA, then the usual card roots.
# With PortMaster: its per-device pad mapping (SDL_GAMECONTROLLERCONFIG) and its platform helper (on muOS it names the
# running program for the OS's close/sleep handling; no helper stops a menu). gptokeyb is never started: its
# SELECT+START exit would kill OZMA, and OZMA reads the pad itself. Without PortMaster: OZMA asks for each button once
# (PAD TEACH).
# Not found: OZMA-NOT-FOUND.txt next to this file.
HERE=$(CDPATH= cd -- "$(dirname -- "$0")" && pwd)
APP=""
for d in "${OZMA_APP:-}" "$HERE/ozma" "$HERE/../App/OZMA" "$HERE/../../App/OZMA" "$HERE/OZMA" /mnt/mmc/App/OZMA /mnt/sdcard/App/OZMA \
         /mnt/SDCARD/App/OZMA /storage/roms/App/OZMA /roms/App/OZMA /roms2/App/OZMA; do
    [ -n "$d" ] && [ -f "$d/launch.sh" ] && [ -f "$d/bricktracker" ] && { APP=$(CDPATH= cd -- "$d" && pwd); break; }
done
if [ -z "$APP" ]; then
    { echo "OZMA was not found. Unpack the OZMA zip into the root of this card (so App/OZMA exists), then start OZMA"
      echo "again. EXPERIMENTAL: OZMA is made for the TrimUI Brick and is untested on this device."; } > "$HERE/OZMA-NOT-FOUND.txt" 2>/dev/null
    exit 1
fi
# PortMaster (optional): its control.txt, the CFW module, the pad mapping for this device, the platform helpers
controlfolder=""
for c in /opt/system/Tools/PortMaster /opt/tools/PortMaster "${XDG_DATA_HOME:-$HOME/.local/share}/PortMaster" \
         /roms/ports/PortMaster /storage/roms/ports/PortMaster /mnt/mmc/MUOS/PortMaster /roms/tools/PortMaster \
         /mnt/SDCARD/Persistent/portmaster/PortMaster /mnt/SDCARD/Apps/PortMaster/PortMaster; do
    [ -f "$c/control.txt" ] && { controlfolder=$c; break; }
done
export OZMA_ENTRY=ports
if [ -n "$controlfolder" ]; then
    export OZMA_ENTRY=portmaster
    source "$controlfolder/control.txt" >/dev/null 2>&1
    [ -n "${CFW_NAME:-}" ] && [ -f "$controlfolder/mod_${CFW_NAME}.txt" ] && source "$controlfolder/mod_${CFW_NAME}.txt" >/dev/null 2>&1
    command -v get_controls >/dev/null 2>&1 && get_controls >/dev/null 2>&1
    [ -n "${sdl_controllerconfig:-}" ] && export SDL_GAMECONTROLLERCONFIG="$sdl_controllerconfig"
    command -v pm_platform_helper >/dev/null 2>&1 && pm_platform_helper "$APP/bricktracker" >/dev/null 2>&1
fi
# App/OZMA/platform/detect.sh picks the settings for this device and OS (PipeWire or dmix, stick as D-pad, no sysfs
# writes, idle hold, ...). Without it (an App/OZMA from before the platform layer): not the Brick, so the system's own
# sound path (PipeWire / dmix), the stick also as a D-pad, clocks left to the OS.
if [ ! -f "$APP/platform/detect.sh" ]; then
    export BT_ALSA_DIRECT="${BT_ALSA_DIRECT:-0}" BT_STICK_AS_DPAD="${BT_STICK_AS_DPAD:-1}" BT_STUDIO="${BT_STUDIO:-0}"
    pidof pipewire >/dev/null 2>&1 && export PIPEWIRE_LATENCY="${PIPEWIRE_LATENCY:-256/48000}"
fi
# the card root for launch.sh's OS checks, when the app sits in <root>/App/OZMA
case "$APP" in */App/OZMA) [ -z "${BT_SD_ROOT:-}" ] && export BT_SD_ROOT="${APP%/App/OZMA}" ;; esac
# The ports package (its app folder holds port.json): songs and settings live BESIDE the app folder, in
# <here>/ozma-data (D9), because PortMaster's uninstall deletes every folder the port lists (OZMA.sh, ozma).
# PS-06 (OZ92-17): an older OZMA folder with its own data/ migrates into <here>/ozma-data via temp+verify+rename
# (never overwriting newer files in ozma-data, never altering originals in ozma/data) and switches BT_DATA only
# after every file verifies. An empty or stock-assets-only ozma-data never hides an unmigrated legacy library.
ozma_ports_has_user_data() { (
    dir=$1; depth=$2
    [ -d "$dir" ] && [ -r "$dir" ] && [ -x "$dir" ] || exit 1
    for entry in "$dir"/* "$dir"/.[!.]* "$dir"/..?*; do
        [ -e "$entry" ] || [ -L "$entry" ] || continue
        base=${entry##*/}
        case "$base" in .ozma-mig.tmp|.ozma-mig-from-legacy|.ozma-mig-merge|.migrated-to-ozma-data|.migrated-to-ozma-data.tmp) continue ;; esac
        if [ "$depth" = root ]; then
            case "$base" in Demos|Bounce) continue ;; esac
            if [ "$base" = Samples ] && [ -d "$entry" ] && [ ! -L "$entry" ]; then
                ozma_ports_has_user_data "$entry" samples && exit 0
                continue
            fi
        elif [ "$depth" = samples ] && [ "$base" = "OZMA KIT" ]; then
            continue
        fi
        if [ -d "$entry" ] && [ ! -L "$entry" ]; then
            ozma_ports_has_user_data "$entry" sub && exit 0
        elif [ -f "$entry" ]; then
            exit 0
        fi
    done
    exit 1
); }

ozma_ports_copy_dir() { (
    src_dir=$1; dst_dir=$2; refresh=$3; depth=$4; ok=0
    [ -r "$src_dir" ] && [ -x "$src_dir" ] || exit 1
    mkdir -p "$dst_dir" 2>/dev/null || exit 1
    rm -f "$dst_dir/.ozma-mig.tmp" 2>/dev/null
    for entry in "$src_dir"/* "$src_dir"/.[!.]* "$src_dir"/..?*; do
        [ -e "$entry" ] || [ -L "$entry" ] || continue
        base=${entry##*/}
        case "$base" in .migrated-to-ozma-data|.migrated-to-ozma-data.tmp|.ozma-mig.tmp|.ozma-mig-from-legacy|.ozma-mig-merge) continue ;; esac
        child_refresh=$refresh; child_depth=sub
        if [ "$depth" = root ]; then
            case "$base" in
                Demos|Bounce) child_refresh=0 ;;
                Samples) child_depth=samples ;;
            esac
        elif [ "$depth" = samples ] && [ "$base" = "OZMA KIT" ]; then
            child_refresh=0
        fi
        if [ -d "$entry" ] && [ ! -L "$entry" ]; then
            ozma_ports_copy_dir "$entry" "$dst_dir/$base" "$child_refresh" "$child_depth" || ok=1
        elif [ -f "$entry" ]; then
            target="$dst_dir/$base"
            need_copy=0
            if [ ! -e "$target" ] && [ ! -L "$target" ]; then
                need_copy=1
            elif [ "$child_refresh" = 1 ] && [ -f "$target" ] && [ ! -L "$target" ] && ! cmp -s "$entry" "$target" 2>/dev/null; then
                need_copy=1
            fi
            if [ "$need_copy" = 1 ]; then
                tmp="$dst_dir/.ozma-mig.tmp"
                rm -f "$tmp" 2>/dev/null
                if cp -f "$entry" "$tmp" 2>/dev/null && cmp -s "$entry" "$tmp" 2>/dev/null && mv -f "$tmp" "$target" 2>/dev/null && [ -f "$target" ]; then
                    :
                else
                    rm -f "$tmp" 2>/dev/null
                    ok=1
                fi
            fi
        fi
    done
    exit "$ok"
); }

ozma_ports_verify_dir() { (
    src_dir=$1; dst_dir=$2; exact=$3; depth=$4
    [ -r "$src_dir" ] && [ -x "$src_dir" ] && [ -d "$dst_dir" ] || exit 1
    [ ! -e "$dst_dir/.ozma-mig.tmp" ] || exit 1
    for entry in "$src_dir"/* "$src_dir"/.[!.]* "$src_dir"/..?*; do
        [ -e "$entry" ] || [ -L "$entry" ] || continue
        base=${entry##*/}
        case "$base" in .migrated-to-ozma-data|.migrated-to-ozma-data.tmp|.ozma-mig.tmp|.ozma-mig-from-legacy|.ozma-mig-merge) continue ;; esac
        child_exact=$exact; child_depth=sub
        if [ "$depth" = root ]; then
            case "$base" in
                Demos|Bounce) child_exact=0 ;;
                Samples) child_depth=samples ;;
            esac
        elif [ "$depth" = samples ] && [ "$base" = "OZMA KIT" ]; then
            child_exact=0
        fi
        if [ -d "$entry" ] && [ ! -L "$entry" ]; then
            ozma_ports_verify_dir "$entry" "$dst_dir/$base" "$child_exact" "$child_depth" || exit 1
        elif [ -f "$entry" ]; then
            [ -f "$dst_dir/$base" ] || exit 1
            if [ "$child_exact" = 1 ]; then cmp -s "$entry" "$dst_dir/$base" 2>/dev/null || exit 1; fi
        fi
    done
    exit 0
); }

if [ -z "${BT_DATA:-}" ] && [ -f "$APP/port.json" ]; then
    LEGACY="$APP/data"
    PERM="$HERE/ozma-data"
    MARKER="$LEGACY/.migrated-to-ozma-data"
    if [ -d "$LEGACY" ] && [ ! -f "$MARKER" ]; then
        MODE_FROM="$PERM/.ozma-mig-from-legacy"
        MODE_MERGE="$PERM/.ozma-mig-merge"
        PERM_HAD_USER=0
        if [ -f "$MODE_FROM" ]; then
            PERM_HAD_USER=0
        elif [ -f "$MODE_MERGE" ]; then
            PERM_HAD_USER=1
        else
            ozma_ports_has_user_data "$PERM" root && PERM_HAD_USER=1
        fi
        REFRESH=1; [ "$PERM_HAD_USER" -eq 1 ] && REFRESH=0
        MODE_FILE="$MODE_FROM"; [ "$PERM_HAD_USER" -eq 1 ] && MODE_FILE="$MODE_MERGE"
        rm -f "$LEGACY/.migrated-to-ozma-data.tmp" 2>/dev/null
        if mkdir -p "$PERM" 2>/dev/null &&
           { [ -f "$MODE_FILE" ] || printf '%s\n' "$PERM_HAD_USER" > "$MODE_FILE" 2>/dev/null; } &&
           ozma_ports_copy_dir "$LEGACY" "$PERM" "$REFRESH" root &&
           ozma_ports_verify_dir "$LEGACY" "$PERM" "$REFRESH" root; then
            MTMP="$LEGACY/.migrated-to-ozma-data.tmp"
            if printf 'migrated to %s on %s\n' "$PERM" "$(date)" > "$MTMP" 2>/dev/null && mv -f "$MTMP" "$MARKER" 2>/dev/null && [ -f "$MARKER" ]; then
                rm -f "$MODE_FROM" "$MODE_MERGE" 2>/dev/null
                export BT_DATA="$PERM"
            else
                rm -f "$MTMP" 2>/dev/null
                if [ "$PERM_HAD_USER" -eq 1 ]; then export BT_DATA="$PERM"; else export BT_DATA="$LEGACY"; fi
            fi
        elif [ "$PERM_HAD_USER" -eq 1 ]; then
            export BT_DATA="$PERM"
        else
            export BT_DATA="$LEGACY"
        fi
    else
        export BT_DATA="$PERM"
    fi
fi
# YOUR OWN SAMPLES: a person's own samples go in OZMA/Samples beside the "ports" folder (the roms folder: the games card's top
# on a two-card system); where the ports folder is <card>/ROMS/Ports (muOS), at the top of that card. Only for the
# ports package; an App/OZMA at a card root finds its own card top in launch.sh.
if [ -z "${OZMA_CARD_TOP:-}" ] && [ -f "$APP/port.json" ]; then
    CT=$(CDPATH= cd -- "$HERE/.." 2>/dev/null && pwd)
    case "$CT" in ?*/ROMS) CT=${CT%/ROMS} ;; esac
    [ -n "$CT" ] && [ "$CT" != / ] && export OZMA_CARD_TOP="$CT"
fi
chmod 0755 "$APP/bricktracker" "$APP/launch.sh" 2>/dev/null   # exFAT / FAT: no exec bits after a copy
cd "$APP" || exit 1
sh ./launch.sh "$@"
RC=$?
command -v pm_finish >/dev/null 2>&1 && pm_finish >/dev/null 2>&1
exit $RC
