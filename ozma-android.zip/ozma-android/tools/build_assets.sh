#!/usr/bin/env bash
# Usage: tools/build_assets.sh /path/to/OZMA-0_9_5-ports.zip
# Needs (Debian/Ubuntu PC):  sudo apt install gcc-aarch64-linux-gnu unzip zip
# Output: app/src/main/assets/runtime.zip   (bin/bricktracker, lib/<glibc + our libSDL2>, data/<Demos,Samples,Bounce>)
#         app/src/main/res/drawable-nodpi/ic_launcher.png
set -euo pipefail
ZIP="${1:?usage: $0 OZMA-0_9_5-ports.zip}"
ROOT="$(cd "$(dirname "$0")/.." && pwd)"
CC="${CC:-aarch64-linux-gnu-gcc}"
SYSROOT="${SYSROOT:-/usr/aarch64-linux-gnu}"     # cross glibc installed by gcc-aarch64-linux-gnu (libc6-arm64-cross)
command -v "$CC" >/dev/null || { echo "missing $CC  ->  sudo apt install gcc-aarch64-linux-gnu"; exit 1; }
[ -f "$SYSROOT/lib/ld-linux-aarch64.so.1" ] || { echo "no glibc at $SYSROOT/lib (set SYSROOT=...)"; exit 1; }

W="$(mktemp -d)"; trap 'rm -rf "$W"' EXIT
unzip -q "$ZIP" -d "$W/src"
APP="$(find "$W/src" -name bricktracker -type f -printf '%h\n' | head -1)"
[ -n "$APP" ] || { echo "bricktracker not found in zip"; exit 1; }
DATA="$(find "$W/src" -maxdepth 2 -type d -name ozma-data | head -1 || true)"
[ -n "$DATA" ] || DATA="$(find "$W/src" -maxdepth 3 -type d -name Samples -printf '%h\n' | head -1 || true)"
echo "app: $APP"; echo "data: ${DATA:-<none>}"

R="$W/rt"; mkdir -p "$R/bin" "$R/lib" "$R/data"
cp "$APP/bricktracker" "$R/bin/"

echo "== building shim (glibc aarch64)"
"$CC" -shared -fPIC -O2 -fvisibility=hidden -Wl,-soname,libSDL2-2.0.so.0 \
      -o "$R/lib/libSDL2-2.0.so.0" "$ROOT/shim/sdl_shim.c" -lpthread

echo "== copying glibc runtime"
for f in ld-linux-aarch64.so.1 libc.so.6 libm.so.6 libpthread.so.0 libdl.so.2; do
  cp -L "$SYSROOT/lib/$f" "$R/lib/$f"
done
[ -n "${DATA:-}" ] && cp -r "$DATA"/. "$R/data/"

mkdir -p "$ROOT/app/src/main/assets" "$ROOT/app/src/main/res/drawable-nodpi"
rm -f "$ROOT/app/src/main/assets/runtime.zip"
( cd "$R" && zip -qr -9 "$ROOT/app/src/main/assets/runtime.zip" . )
[ -f "$APP/icon.png" ] && cp "$APP/icon.png" "$ROOT/app/src/main/res/drawable-nodpi/ic_launcher.png"
sha256sum "$APP/bricktracker" | cut -c1-16 > "$ROOT/app/src/main/assets/runtime.id"
ls -lh "$ROOT/app/src/main/assets/runtime.zip"
echo "OK. Now open the project in Android Studio and build."
